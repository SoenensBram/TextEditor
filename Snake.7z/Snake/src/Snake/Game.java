/*
 * implementatie:
 * knop: new game en scoreboard
 * als gameover return score to score board
 * 
 * Geen linked list (pre def)
 * wel private class
 * linkedlist van in de les (coppy paste)
 * 
 * met size de tail grounden
 * size+1 als eten
 * 
 * eerst eten colision voor lichaam collision (staartpunt)
 * 
 *  richting beveiligen
 *  
 *  new game => while lus tot game over
 *  
 *  Move de input updaten
 *  
 *  Kimpende methode aantoepen op trage timer
 *  Food methode aanroepene op gemiddelde timers
 *  Move aantoepen op korte timer
 *  Input onafhangkelijk van timer;
 */
package Snake;
//TODO TIMERS
/**
 * java classes:
 * swing voor GUI
 * awt voor figuren
 * util voor random nummers
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.*;

public class Game abstract Runnable{	
	//Linked List variabelen
	private LinkedList<int[]> slang;private LinkedList<int[]> eten;private LinkedList<int[]> restLengte;
	//Array variabelen
	private int[] nextCoordinaatHead;private int[] frame;
	//int variabelen
	private int score;private int DirectionChange;private int food;private int slangLengte;private int foodSaturation;
	private int restSpawn; private int Direction;private int timeRest;
	//boolean variabelen
	private boolean grow; private boolean gameOver;
	
	/*
	 * this method defines all the starting variabels
	 */
	public Game(){
		frame = new int[]{100,100};
		slang.add(new int[]{50,50});
		slang.add(new int[]{50,49});
		slangLengte = 2;
		Direction = 3;
		nextCoordinaatHead = new int[2];
		grow = false;
		foodSaturation = 800;
		restSpawn = 30;
		new java.util.Timer().scheduleAtFixedRate(
				new java.util.TimerTask(){
					public void run(){
						 MoveUpdate();
					}
				}
		, 30, 30);
	}
	
	/*
	 * This is call onces per tick this runs the game
	 */
	//TODO in timer
	private void MoveUpdate(){
		DirectionChange = Direction;
		this.MoveAction(0);
	}
	
	/*
	 * This method calls Colision
     * This is the method that determans what to do if a move is made.
	 * Direction:
	 * 1 = up
	 * 2 = right
	 * 3 = down
	 * 4 = left
	 */
	private void MoveAction(int DirectionChanges){
		int CoordHeadX = slang.first()[0];
		int CoordHeadY = slang.first()[1];
		if(DirectionChanges == 1){
			CoordHeadY +=1;
			nextCoordinaatHead = new int[]{CoordHeadX,CoordHeadY};
			this.Colison();
		}
		if(DirectionChanges == 2){
			CoordHeadX +=1;
			nextCoordinaatHead = new int[]{CoordHeadX,CoordHeadY};
			this.Colison();
		}
		if(DirectionChanges == 3){
			CoordHeadY -=1;
			nextCoordinaatHead = new int[]{CoordHeadX,CoordHeadY};
			this.Colison();
		}
		if(DirectionChanges == 4){
			CoordHeadX-=1;
			nextCoordinaatHead = new int[]{CoordHeadX,CoordHeadY};
			this.Colison();
		}
		this.Colison();
		score = score +1;
	}
	
	/*
	 * Collision method:
	 * determans what hapens
	 */
	private void Colison(){
		//@random variable
		//Checking if we are going back to the prevouis tile
		if(slang.get(0) == nextCoordinaatHead){
			DirectionChange = DirectionChange +1;
			if(DirectionChange > 4)DirectionChange=1;
			this.MoveAction(DirectionChange);
		}
		//Checking if we collide with the wall
		if(nextCoordinaatHead[0] == 0){
			this.gameOver();
		}
		if(nextCoordinaatHead[0] == 100){
			this.gameOver();
		}
		if(nextCoordinaatHead[1] == 0){
			this.gameOver();
		}
		if(nextCoordinaatHead[1] == 100){
			this.gameOver();
		}
		//Checking if we can eat food or have rest
		int ListCycle = 0;
		grow = false;
		if(restLengte.get(0) != slang.get(0)){
			while(ListCycle <= eten.size()){
				if(nextCoordinaatHead == eten.get(ListCycle)){
					grow = true;
				}
			}
		}else{
			slang.keep2Leads();
			score += 10000;
		}
		if(grow = false){
			slang.removeLast();
		}else{
			slangLengte =+1;
			score =+ 1;
		}
		//Checking if we colide with our own boddy
		ListCycle = 2;
		while(ListCycle<= slang.size()){
			if(slang.first() == slang.get(ListCycle)){
				this.gameOver();
			}
			ListCycle = ListCycle+1;
		}
		slang.prepend(nextCoordinaatHead);
		score++;
	}
	
	/*
	 * This Code is writen to generate food randomly (with a timer)
	 */
	//TODO in timer
	private void foodGeneration(){
		food = (((frame[0]*frame[1])-slangLengte)/foodSaturation)+1;
		int LoopCounter = 0;
		int Xas;int Yas;
		while(LoopCounter<=food){
			int SlangCounter = 0;
			int uniek = SlangCounter;
			Xas = (int) ((Math.random()*(frame[0]-2))+1);
			Yas = (int) ((Math.random()*(frame[1]-2))+1);
			int[] tmpCoord = new int[]{Xas,Yas};
				while(slang.size() == SlangCounter){
					if(tmpCoord != slang.get(SlangCounter)){uniek =+1;}
					SlangCounter =+ 1;
				}
			if(uniek == slang.size()){
				eten.set(LoopCounter, tmpCoord);
				LoopCounter =+1;
			}
		}
	}
	
	/*
	 * This will generate a food reste item to rest the size of the snake
	 * the time is dependant on the size of the snake (spawn)
	 */
	//TODO in timer
	private void restSizeItem(){
		if(restSpawn-slangLengte<=0){
			timeRest = slangLengte-restSpawn;
		}else{timeRest =0;}
	}
	
	private int gameOver(){
		new java.util.Timer().cancel();
		return score;
	}
	
	public void keyTyped(KeyEvent event){
		if(event.getKeyCode() == KeyEvent.VK_UP)Direction=1;
		else{if(event.getKeyCode() == KeyEvent.VK_RIGHT)Direction=2;
		else{if(event.getKeyCode() == KeyEvent.VK_DOWN)Direction=3;
		else{if(event.getKeyCode() == KeyEvent.VK_LEFT)Direction=4;}}}
	}
	
	

	
	/*
	 * Main method
	 */
	public static void main(String[] args){
		new Game();
	}
}
