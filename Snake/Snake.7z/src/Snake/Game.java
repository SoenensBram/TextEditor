/*
 * implementatie:
 * knop: new game en scoreboard
 * als gameover return score to score board
 * 
 * Geen linked list (pre def)
 * wel private class
 * linkedlist van in de les (coppy paste)
 * 
 * met size de tail grounden
 * size+1 als eten
 * 
 * eerst eten colision voor lichaam collision (staartpunt)
 * 
 *  richting beveiligen
 *  
 *  new game => while lus tot game over
 *  
 *  Move de input updaten
 *  
 *  Kimpende methode aantoepen op trage timer
 *  Food methode aanroepene op gemiddelde timers
 *  Move aantoepen op korte timer
 *  Input onafhangkelijk van timer;
 */
package Snake;
//TODO TIMERS
/**
 * java classes:
 * swing voor GUI
 * awt voor figuren
 * util voor random nummers
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

import java.lang.Math;

public class Game{
	//int variabelen
	private int score;private int DirectionChange;private int food;private int slangLengte;private int foodSaturation;
	private int restSpawn; private int Direction;private int timeRest;
	//boolean variabelen
	private boolean grow; private boolean gameOver;
	//Linked List variabelen
	private LinkedList<Coordinaten> slang;
	private LinkedList<Coordinaten> eten;
	private LinkedList<Coordinaten> restLengte;
	//Coordinaat variabelen
	private Coordinaten nextCoordinaatHead;private Coordinaten frameGR;
	
	/*
	 * this method defines all the starting variabels
	 */
	public Game(){
		frameGR = new Coordinaten(100,100);
		slang.add(new Coordinaten(50,50));
		slang.add(new Coordinaten(50,49));
		slangLengte = 2;
		Direction = 3;
		grow = false;
		foodSaturation = 800;
		restSpawn = 30;
		new java.util.Timer().scheduleAtFixedRate(
				new java.util.TimerTask(){
					public void run(){
						 MoveUpdate();
					}
				}
		, 30, 30);
	}
	
	/*
	 * This is call onces per tick this runs the game
	 */
	//TODO in timer
	private void MoveUpdate(){
		DirectionChange = Direction;
		this.MoveAction(0);
	}
	
	/*
	 * This method calls Colision
     * This is the method that determans what to do if a move is made.
	 * Direction:
	 * 1 = up
	 * 2 = right
	 * 3 = down
	 * 4 = left
	 */
	private void MoveAction(int DirectionChanges){
		int CoordHeadX = slang.first().getX();
		int CoordHeadY = slang.first().getY();
		if(DirectionChanges == 1){
			CoordHeadY +=1;
			nextCoordinaatHead = new Coordinaten(CoordHeadX,CoordHeadY);
			this.Colison();
		}
		if(DirectionChanges == 2){
			CoordHeadX +=1;
			nextCoordinaatHead = new Coordinaten(CoordHeadX,CoordHeadY);
			this.Colison();
		}
		if(DirectionChanges == 3){
			CoordHeadY -=1;
			nextCoordinaatHead = new Coordinaten(CoordHeadX,CoordHeadY);
			this.Colison();
		}
		if(DirectionChanges == 4){
			CoordHeadX-=1;
			nextCoordinaatHead = new Coordinaten(CoordHeadX,CoordHeadY);
			this.Colison();
		}
		this.Colison();
		score = score +1;
	}
	
	/*
	 * Collision method:
	 * determans what hapens
	 */
	private void Colison(){
		//@random variable
		//Checking if we are going back to the prevouis tile
		if(slang.get(0) == nextCoordinaatHead){
			DirectionChange = DirectionChange +1;
			if(DirectionChange > 4)DirectionChange=1;
			this.MoveAction(DirectionChange);
		}
		//Checking if we collide with the wall
		if(nextCoordinaatHead.getX() == 0){
			this.gameOver();
		}
		if(nextCoordinaatHead.getX() == 100){
			this.gameOver();
		}
		if(nextCoordinaatHead.getY() == 0){
			this.gameOver();
		}
		if(nextCoordinaatHead.getY() == 100){
			this.gameOver();
		}
		//Checking if we can eat food or have rest
		int ListCycle = 0;
		grow = false;
		if(restLengte.get(0) != slang.get(0)){
			while(ListCycle <= eten.size()){
				if(nextCoordinaatHead == eten.get(ListCycle)){
					grow = true;
				}
			}
		}else{
			slang.keep2Leads();
			score += 10000;
		}
		if(grow = false){
			slang.removeLast();
		}else{
			slangLengte =+1;
			score =+ 1;
		}
		//Checking if we colide with our own boddy
		ListCycle = 2;
		while(ListCycle<= slang.size()){
			if(slang.first() == slang.get(ListCycle)){
				this.gameOver();
			}
			ListCycle = ListCycle+1;
		}
		slang.prepend(nextCoordinaatHead);
		score++;
	}
	
	/*
	 * This Code is writen to generate food randomly (with a timer)
	 */
	//TODO in timer
	private void foodGeneration(){
		food = (((frameGR.getX()*frameGR.getY())-slangLengte)/foodSaturation)+1;
		int LoopCounter = 0;
		int Xas;int Yas;
		while(LoopCounter<=food){
			int SlangCounter = 0;
			int uniek = SlangCounter;
			Xas = (int) ((Math.random()*(frameGR.getX()-2))+1);
			Yas = (int) ((Math.random()*(frameGR.getY()-2))+1);
			Coordinaten tmpCoord = new Coordinaten(Xas,Yas);
				while(slang.size() == SlangCounter){
					if(tmpCoord != slang.get(SlangCounter)){uniek =+1;}
					SlangCounter =+ 1;
				}
			if(uniek == slang.size()){
				eten.set(LoopCounter, tmpCoord);
				LoopCounter =+1;
			}
		}
	}
	
	/*
	 * This will generate a food reste item to rest the size of the snake
	 * the time is dependant on the size of the snake (spawn)
	 */
	//TODO in timer
	private void restSizeItem(){
		if(restSpawn-slangLengte<=0){
			timeRest = slangLengte-restSpawn;
		}else{timeRest =0;}
	}
	
	private int gameOver(){
		new java.util.Timer().cancel();
		return score;
	}
	
	public void keyTyped(KeyEvent event){
		if(event.getKeyCode() == KeyEvent.VK_UP)Direction=1;
		else{if(event.getKeyCode() == KeyEvent.VK_RIGHT)Direction=2;
		else{if(event.getKeyCode() == KeyEvent.VK_DOWN)Direction=3;
		else{if(event.getKeyCode() == KeyEvent.VK_LEFT)Direction=4;}}}
	}
	
	public LinkedList<Coordinaten> get(){
		return slang;
	}
	
	/*
	 * Opdracht1 schildpad 1e semester
	 */
	/*private class GameWindow{
		//TODO slang vervangen
		private JFrame frame;
		private TekenPaneel paneel;
		private Graphics gB;
		private Image buffer;
		
		private HashSet<LinkedList<int[]>> database;
		private HashMap<String,Color> kleurMap;
		
		public GameWindow(String titel){
			frame = new JFrame(titel);
			paneel = new TekenPaneel();
			frame.setContentPane(paneel);
			paneel.setPreferredSize(new Dimension(frameGR[0]*10, frameGR[1]*10));
			frame.pack();
			database = new HashSet<LinkedList<int[]>>();
			kleurMap = new HashMap<String,Color>();
			kleurMap.put("rood", Color.red);
			maakZichtbaar(true);
		}
		
		public void maakZichtbaar(boolean zichtbaar){
			if(gB == null){
				Dimension dim = paneel.getSize();
				buffer = frame.createImage(dim.width,dim.height);
				gB = buffer.getGraphics();
			}
			frame.setVisible(zichtbaar);
		}
		
		public void teken(LinkedList<int[]> s){
			s = get();
			database.add(s);
			herschilder();
		}
		
		public void verwijder(LinkedList<int[]> s){
			s = get();
			database.remove(s);
			herschilder();
		}
		
		private void maakBufferSchoon(){
			gB.setColor(Color.red);
			Dimension dim = paneel.getSize();
			gB.fillRect(0,0,dim.width,dim.height);
		}
		
		private void tekenSlang(LinkedList<int[]> s){
			s = get();
			String kleur = s.getKleur();
			Color color = kleurMap.get(kleur);
			if(color != null) gB.setColor(color);
			else gB.setColor(Color.black);
			
			//kop
			tekenCirkel(s.get(0)[0],s.get(0)[1]);
			//lijf
			if(s.size()>2){
				for(int grootte=1;grootte<(s.size()-2);grootte++){
					tekenVierKant(s.get(grootte)[0],s.get(grootte)[1]);
				}
			}
			//staart
			tekenTriangle(s.get(.size()-1)[0],s.get(s.size()-1)[1])
			
			//food
			//TODO
			tekenVierKant();
			
			//restItem
			//TODO
		}
		
		private void tekenCirkel(double xMpt, double yMpt){
			gB.fillOval(Math.round(xMpt -5), Math.round(yMpt-5), 10, 10);
		}
		
		private void tekenVierKant(double xMpt, double yMpt){
			gB.fillRect(Math.round(xMpt-5), Math.round(yMpt-5), 10, 10);
		}
		
		private void tekenTraingle(double xMpt, double yMpt){
			gB.fillRect(Math.round(xMpt-5), Math.round(yMpt-5), 6, 6);
		}
		
		private class TekenPaneel extends JPanel{
			public void paint(Graphics g){
				g.drawImage(buffer,0,0,null);
			}
		}
	}
	*/
	
	/*
	 * Main method
	 */
	public static void main(String[] args){
		new Game();
	}
}
